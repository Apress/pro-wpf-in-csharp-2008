using System;
using System.Windows;

namespace ColorPickerSample
{
    public class Test
    {
        [STAThread]
        static void Main()
        {
            ColorPickerDialog cpd = new ColorPickerDialog();
            cpd.ShowDialog();
        }
    }
}